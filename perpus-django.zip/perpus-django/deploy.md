# 0. Create Server
Dalam kasus ini, kalian harus membuat server sendiri, bisa menggunakan VirtualBox atau Komputer Fisik atau sewa VPS.
Sistem operasi yang digunakan: Ubuntu 16.04 LTS.

# 1. Update Install Python 3
- [x] update
- [x] install python3 nginx
- [x] install virtual env.

# 2. Install App.Perpustakaan
- [x] clone github.com/writerlab/perpus
- [x] konfigurasi app.

# 3. Membuat Service Gunicorn
- [x] buat service
- [x] aktifkan service

# 4. Konfigurasi Nginx
- [x] buat file konfig.
- [x] aktifkan konfig. web server-nya
- [x] buka firewall untuk akses port 80
